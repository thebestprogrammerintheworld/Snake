#include "Snake.h"

char gameboard[8][8];

void walls_cls::generate_gameboard(){
	for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
			gameboard[i][j] = 0;
        }
    }
} 
void snake_cls::initialize(){
	for(int i=0;i<3;i++){
		snake_rows[i] = 4;
        snake_columns[i] = i+4;
    }
    snake_len = 3;
    row_speed = 0;
    column_speed = -1;
}
void snake_cls::movement(){
	char serial_receive;
	if(Serial.available()>0){
		serial_receive = Serial.read();   
        if(serial_receive=='0' && row_speed != 1){  //up
            row_speed = -1;
            column_speed = 0;
        }
        else if(serial_receive=='1' && row_speed != -1){    //down
            row_speed = 1;
            column_speed = 0;
        }
        else if(serial_receive=='2' && column_speed != 1){  //left
            row_speed = 0;
            column_speed = -1;
        }
        else if(serial_receive=='3' && column_speed != -1){  //right
            row_speed = 0;
            column_speed = 1;
        }
    }
}
void snake_cls::head_move(){
	snake_columns[0] += column_speed;
    snake_rows[0] += row_speed;
    if(snake_columns[0]<0){
		snake_columns[0] = 7;
    }
    else if(snake_columns[0]>7){
		snake_columns[0] = 0;
    }
    else if(snake_rows[0]<0){
		snake_rows[0] = 7;
    }
    else if(snake_rows[0]>7){
		snake_rows[0] = 0;
	}
}
void snake_cls::tail_follow(int length){
    for(int i=length-1;i>0;i--){
		snake_rows[i] = snake_rows[i-1];
        snake_columns[i] = snake_columns[i-1];
    }
}
void snake_cls::generate_snake(){
	for(int i=0;i<snake_len;i++){
		gameboard[snake_rows[i]][snake_columns[i]] = 1;
    }
}
fruit_cls::fruit_cls(){
    fruit_exists = 0;
}
void fruit_cls::place_fruit(){
    if(fruit_exists==0){
		while(true){
			fruit_row = random(8);
            fruit_column = random(8);
            if(gameboard[fruit_row][fruit_column]!= 1){
				gameboard[fruit_row][fruit_column] = 1;
				fruit_exists = 1;
                break;
            }
        }
    }
    else{
		gameboard[fruit_row][fruit_column] = 1;
    }
}
void fruit_cls::check_fruit(int check){
	if(check==1){
		fruit_exists = 0;
	}
}
void game_setup::restart(int intensity, class MaxMatrix m){
	Serial.begin(9600);
	m.init();
	m.setIntensity(intensity);
	randomSeed(analogRead(0));
	Serial.write("1");
}
int generate_cls::collect(){
	if(snake_rows[0]==fruit_row && snake_columns[0]==fruit_column){
		snake_len++;
		return 1;
	}
	return 0;
}
void generate_cls::draw(class MaxMatrix m){
    for(int i=0;i<8;i++){
		for(int j=0;j<8;j++){
			m.setDot(j,i,gameboard[i][j]);
		}
    }
}
void generate_cls::game_over(){
	for(int i=1;i<snake_len;i++){
		if(snake_columns[0]==snake_columns[i] && snake_rows[0]==snake_rows[i]){
			initialize();
		}
	}
}