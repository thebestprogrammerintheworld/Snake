#ifndef Snake_h
#define Snake_h

#include "Arduino.h"
#include "MaxMatrix.h"
#include "time.h"

extern char gameboard[8][8];

class walls_cls{
	public:
		void generate_gameboard(); // generates empty gameboard space by assigning 0's.
};
class snake_cls{
	public:
		int snake_rows[100], snake_columns[100], row_speed, column_speed, snake_len;
		void initialize(); // initializes snake position, length and speed when the game is started/restarted/lost
		void movement(); // function responsible for serial communication and interpretation of received code (generated with python) from keystrokes
		void head_move(); // head moves first. IF functions check if the head has reached the boundary
		void tail_follow(int length); // tail follows head. Each dot is moved to the current position of the dot that is in front of it. Used with snake_len
		void generate_snake(); // assigns 1's to the gameboard according to the coordinates of snake
};
class fruit_cls{
	public:
		fruit_cls();
		int fruit_row, fruit_column, fruit_exists;
		void place_fruit(); // places a fruit at a random empty location on the gameboard.
		void check_fruit(int check); // checks if there is a fruit present on the gameboard, must be used with collect()
};
class game_setup{
	public:
		void restart(int intesity, class MaxMatrix m);
};
class generate_cls: public walls_cls, public snake_cls, public fruit_cls, public game_setup{
	public:
		int collect(); // if snake head's coordinates coincides with coordinates of the fruit, then the fruit is collected, snake grows and 1 is returned indicating that a new fruit must be placed on the gameboard
		void draw(class MaxMatrix m); // turns LED's on the LED array according to the collected coordinates stored in the gameboard array. 1 = LED ON; 2 = LED OFF
		void game_over(); // checks if the snake head isn't eating its tail. If it is, then the game is restarted by calling initialize().
};

#endif